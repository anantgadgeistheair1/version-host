# version-host
This repo hosts the version.txt file for CDN delivery via Cloudflare Pages.